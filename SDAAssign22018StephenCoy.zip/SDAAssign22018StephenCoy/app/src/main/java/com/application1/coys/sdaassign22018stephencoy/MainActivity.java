package com.application1.coys.sdaassign22018stephencoy;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class MainActivity extends AppCompatActivity {

    static final int REQUEST_IMAGE_CAPTURE = 1;
    TextView textView;
    File photoFile = null;
    String mCurrentPhotoPath;
    private static final int READ_REQUEST_CODE = 42;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textView = (TextView) findViewById(R.id.CameraOn);

        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                captureImage();
                Log.d("oncreate", "camera button");
            }
        });
            Log.d("oncreate", "camera text view");
            textView = (TextView) findViewById(R.id.textView2);
                textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                performFileSearch();
            }
        });
            Log.d("oncreate", "File opener text view");
            textView = (TextView) findViewById(R.id.textView3);
                textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                callActivity();
            }
        });
            Log.d("oncreate", "call activity");
            // Get the Intent that started this activity and extract the string
             Intent intent = getIntent();
                String message = intent.getStringExtra(CallanActivity.EXTRA_MESSAGE);

             // Capture the layout's TextView and set the string as its text
             TextView textView = findViewById(R.id.textView4);
                textView.setText(message);

        Button sendBtn = (Button) findViewById(R.id.EmailButton);
        sendBtn.setEnabled(false);

        if(getIntent().hasExtra("state")){//https://stackoverflow.com/questions/43386797/enable-button-from-another-activity
           // enable send button if data passed back from the second activity
            if (getIntent().getStringExtra("state").equals("success")){
                sendBtn.setEnabled(true);
            }
                else{
                    sendBtn.setEnabled(false);
                }
        }
        else{
            sendBtn.setEnabled(false);
        }
        sendBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                sendEmail();
                Log.i("oncreate", "email button");
            }
        });
    }

    public void captureImage() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        // Ensure that there's a camera activity to handle the intent
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            // Create the File where the photo should go
            try {
                photoFile = createImageFile();
            }
            catch (IOException ex) { Log.d("info log", "exception");
                // Error occurred while creating the File
            }
            // Continue only if the File was successfully created
            if (photoFile != null) {
                Uri photoURI = FileProvider.getUriForFile(this,
                        "com.application1.coys.sdaassign22018stephencoy.fileprovider",
                        photoFile);
                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
            galleryAddPic();
        }
            else {
                displayMessage(getBaseContext(), "Request cancelled or something went wrong.");
            }
    }

    public File createImageFile() throws IOException {
        // Create an image file name
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String imageFileName = "JPEG_" + timeStamp + "_";
        File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
        File image = File.createTempFile(
                imageFileName,  /* prefix */
                ".jpg",         /* suffix */
                storageDir      /* directory */
        );

        // Save a file: path for use with ACTION_VIEW intents
        mCurrentPhotoPath = image.getAbsolutePath();
        return image;
    }

    private void displayMessage(Context context, String message) {
        Toast.makeText(context, message, Toast.LENGTH_LONG).show();
    }

    public void galleryAddPic() { //add image to gallery
        Intent mediaScanIntent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
        File f = new File(mCurrentPhotoPath);
        Uri contentUri = Uri.fromFile(f);
        mediaScanIntent.setData(contentUri);
        this.sendBroadcast(mediaScanIntent);
    }

     // Launch an intent to open up the "file chooser" UI and select an image.
    public void performFileSearch() {

        // ACTION_OPEN_DOCUMENT is the intent to choose a file via the system's file browser.
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);

        // Filter to only show results that can be "opened", such as a file
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        Uri uri = Uri.parse(Environment.getExternalStorageDirectory().getPath()
                + "/Android/data/com.application1.coys.sdaassign22018stephencoy/files/Pictures/");

        // Filter to show all file types, using the */* data type.
        // Search for all documents available via installed storage providers
        intent.setType("*/*");

        startActivityForResult(intent, READ_REQUEST_CODE);
    }


     // Called when the user taps the Send button
    public void callActivity() {
        // Do something in response to button
        Intent intent = new Intent(this, CallanActivity.class);
        startActivity(intent);

    }

    public void sendEmail() { //https://stackoverflow.com/questions/8701634/send-email-intent
        //start new intent for email
        Intent intent = getIntent();
        Log.i("Info log","Email called" );
         //experimenting with ways of getting the text from second activity to main activity
        String recipients = null;
        String subject = null;
        String body = null;
        Bundle bundle = getIntent().getExtras();
            if (bundle != null){
                 recipients = bundle.getString("RECIPIENT_MESSAGE");
                 subject = bundle.getString("SUBJECT_MESSAGE");
                 body = bundle.getString("BODY_MESSAGE");
            }
        // pull the data from second activity into this activity

        Intent email = new Intent(Intent.ACTION_SEND, Uri.parse("mailto:"));
        // prompts email clients only
        email.setType("message/rfc822");

        email.putExtra(Intent.EXTRA_EMAIL, new String []{recipients});
        email.putExtra(Intent.EXTRA_SUBJECT, subject);
        email.putExtra(Intent.EXTRA_TEXT, body);

        try {
            // the user can choose the email client
            startActivity(Intent.createChooser(email, "Choose an email client from..."));

        }
        catch (android.content.ActivityNotFoundException ex) {
            //set a toast t tell the user if there is no email client
            Toast.makeText(MainActivity.this, "No email client installed.",
                    Toast.LENGTH_LONG).show();
        }
    }

}









