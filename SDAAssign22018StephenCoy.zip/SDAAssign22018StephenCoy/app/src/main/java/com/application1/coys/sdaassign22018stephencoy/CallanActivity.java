package com.application1.coys.sdaassign22018stephencoy;


import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;


public class CallanActivity extends AppCompatActivity {
    public static final String EXTRA_MESSAGE = "";
    public static final String RECIPIENT_MESSAGE = "RECIPIENT_MESSAGE";
    public static final String SUBJECT_MESSAGE = "";
    public static final String BODY_MESSAGE = "";
    private static int REQUEST_CODE = 12;

    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_callan);

        //allow for up navigation and back arrow at top of screen
        getSupportActionBar().setDefaultDisplayHomeAsUpEnabled(true);//https://www.youtube.com/watch?v=EBRXkictWss
    }

    public void sendMessage(View view) { //https://stackoverflow.com/questions/14466017/how-do-you-display-content-of-multiple-edit-text-fields-to-one-text-view
        Log.d("callanactivity", "edit text fields input");
        Intent intent = new Intent(this, MainActivity.class);
            intent.putExtra("state", "success");//allow send button to be enabled in main activity
                EditText EditTo = (EditText) findViewById(R.id.editTo);
                EditText EditSubject = (EditText) findViewById(R.id.editSubject);
                EditText EditCompose = (EditText) findViewById(R.id.editCompose);
                 Log.d("callanactivity", "edit text fields input");
        String to = EditTo.getText().toString();
        String Subject = EditSubject.getText().toString();
        String Compose = EditCompose.getText().toString();
        String message = to + "\n" + Subject + " \n" + Compose;
        // put the 'to', 'subject' and 'compose' edit text fields inputted values into constants that can be called by the main activity
        intent.putExtra(RECIPIENT_MESSAGE, to);
        intent.putExtra(SUBJECT_MESSAGE, Subject);
        intent.putExtra(EXTRA_MESSAGE, message);
        startActivityForResult(intent, REQUEST_CODE = 12);

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
    }
}



